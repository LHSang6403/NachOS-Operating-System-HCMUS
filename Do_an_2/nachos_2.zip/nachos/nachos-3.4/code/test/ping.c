#include "syscall.h"
#include "copyright.h"

int main()
{
    int i = 0;
    for (i = 0; i < 1000; i++)
    {
        Printf("A");
    }
}