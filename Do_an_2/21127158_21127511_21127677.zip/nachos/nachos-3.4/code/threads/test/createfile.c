#include "syscall.h"
#include "copyright.h"
#define maxlen 32
int main(){
	int len;
	char filename[maxlen +1];
	//char* word = "Hello word";
	//word[9] = '\0';
	/*Create a file*/
	//if (Create("text.txt") == -1)
	//{
	//	printf("Tap tin loi");
	//}
	//else
	//{
	//	printf("Tao thanh cong");
	// xuất thông báo tạo tập tin thành công
	//}
	Scanf(filename, 32);
	Printf(filename);
	Halt();
}
